App({
  globalData: {
    students: [
      { id: 102101315, name: "王辉凡" },
      { id: 102101316, name: "里斯" },
      { id: 102101317, name: "张三" },
    ],
    leaveList: [],
    absentList: [],
    currentIndex: 0,
  },
});