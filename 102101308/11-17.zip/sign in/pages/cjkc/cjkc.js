// pages/cjkc/cjkc.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        msg0:'例：吴彦祖',
        msg1:'例：软件工程A',
        msg2:'例：东一305',
        msg3:'例：周五',
        msg4:'例：一二节 ',
        
        index:0
    },
     
    pickerchange(e){
       this.setData({
           index:e.detail.value
       })
    },
    jump3:function(){
        console.log('dianl')
        wx.navigateTo({
          url: '/pages/jssy/jssy',
        })
    },
      
    
    showActionSheet: function() {
        wx.showActionSheet({
          itemList: this.data.items,
          success: function(res) {
            console.log('用户选择了：' + res.tapIndex);
          }
        });
      },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})